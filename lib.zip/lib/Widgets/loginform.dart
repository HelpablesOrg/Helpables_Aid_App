import 'package:aid_app/Screens/forgot_password.dart';
import 'package:aid_app/Screens/home_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_signin_button/button_list.dart';
import 'package:flutter_signin_button/button_view.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
class Loginform extends StatefulWidget {
  const Loginform({super.key});
  @override
  State<StatefulWidget> createState() => _LoginformState();
}
class _LoginformState extends State<Loginform> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  bool _obscurePassword = true;
    final FirebaseAuth _auth = FirebaseAuth.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();
  Future<void> _signInWithGoogleForExistingAccount() async {
    try {
      final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
      if (googleUser == null) {
        print("Google Sign-In cancelled by user.");
      }

      final GoogleSignInAuthentication? googleAuth = await googleUser?.authentication;

      final AuthCredential credential = GoogleAuthProvider.credential(
        accessToken: googleAuth!.accessToken,
        idToken: googleAuth.idToken,
      );

      final UserCredential userCredential = await _auth.signInWithCredential(credential);

      final User? user = userCredential.user;
      if (userCredential.additionalUserInfo?.isNewUser == true) {
    
        await _auth.signOut();
        print("Sign-in failed: User does not exist in Firebase.");
  
      }
else{
   Navigator.push(context, MaterialPageRoute(builder: (context) {
                          return HomeScreen();
                         }));
}
      // Return the signed-in user
      print("User logged in: ${user?.email}");
    } catch (e) {
      print("Google sign in error: $e");
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Google Sign in failed. Please try again')));
    }
  }
signIn ()async{
  try{  
    UserCredential userCredential =
    await FirebaseAuth.instance.signInWithEmailAndPassword(email: _emailController.text, password: _passwordController.text);
  print("User signed in: ${userCredential.user?.email}");
   ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("User signed in: ${userCredential.user?.displayName}")));
          Navigator.push(context, MaterialPageRoute(builder: (context) {
                          return HomeScreen();
                         }));

} catch (e) {

    ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Error signing in: $e")));
    print("Error signing in: $e");
  }

}


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Form(
          key: _formKey,
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextFormField(
                  controller: _emailController,
                  keyboardType: TextInputType.emailAddress,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return "Please enter email";
                    }
                    final emailRegex = RegExp(r'^[^@]+@[^@]+\.[^@]+');
                    if (!emailRegex.hasMatch(value)) {
                      return 'Enter a valid email address';
                    }
                    return null;
                  },
                  onFieldSubmitted: (value) {
                    _formKey.currentState!.validate();
                  },
                  decoration: InputDecoration(
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8)),
                      labelText: 'Email'),
                ),
                SizedBox(height: 16),
                TextFormField(
                  controller: _passwordController,
                  validator: (value) {
                 
                    if (value == null || value.isEmpty) {
                      return "Please enter password";
                    }
                    if (value.length < 7) {
                      return 'Password must be at least 7 characters long';
                    }
                    return null;
                  },
                  onFieldSubmitted: (value) {
                    _formKey.currentState!.validate();
                  },
                  obscureText: _obscurePassword,
                  decoration: InputDecoration(
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8)),
                      labelText: 'Password',
                      suffixIcon: IconButton(
                          onPressed: () {
                            setState(() {
                              _obscurePassword = !_obscurePassword;
                            });
                          },
                          icon: Icon(_obscurePassword
                              ? Icons.visibility_off
                              : Icons.visibility))),
                ),
                SizedBox(height: 16),
                Align(
                  alignment: Alignment.center,
                  child: ElevatedButton(
                    onPressed: () {

                      if (_formKey.currentState!.validate()) {
                      signIn();

                      }
                    },
                    style: ElevatedButton.styleFrom(
                        padding: EdgeInsets.all(8),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16)),
                        backgroundColor: Colors.blueAccent),
                    child: Text(
                      'Login',
                      style: TextStyle(color: Colors.black),
                    ),
                  ),
                ),
                Align(
                  alignment: Alignment.center,
                  child: TextButton(
                      onPressed: () {
                         Navigator.push(context, MaterialPageRoute(builder: (context) {
                          return ForgotPassword();
                         }));
                      },
                      child: Text(
                        'Forgot Password?',
                        style: TextStyle(color: Colors.grey, fontSize: 14),
                      )),
                ),
                SizedBox(height: 16),
                Align(
                  alignment: Alignment.center,
                  child: SignInButton(
                    Buttons.Google,
                    text: 'Log in with Google',
                    elevation: 8,
                    onPressed: _signInWithGoogleForExistingAccount,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16)),
                  ),
                )
              ],
            ),
          )),
    );
  }
}