import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class Google_Login extends StatefulWidget {
  const Google_Login({super.key});

  @override
  State<Google_Login> createState() => _Google_LoginState();
}

class _Google_LoginState extends State<Google_Login> {
  final FirebaseAuth _auth= FirebaseAuth.instance;
  User? _user;
@override
  void initState() {
    super.initState();
    _auth.authStateChanges().listen(( event){
      setState(() {
        _user=event;
      });
    });
  }


  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}