import 'package:aid_app/Widgets/loginform.dart';
import 'package:flutter/material.dart';

class LoginScreen extends StatefulWidget{
  LoginScreen({super.key});
  @override
  State<StatefulWidget> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen>{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
appBar: AppBar(
),
body: Loginform()
    );
  }
}