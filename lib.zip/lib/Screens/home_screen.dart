import 'package:aid_app/Widgets/loginform.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  
  final FirebaseAuth _auth = FirebaseAuth.instance;
   final GoogleSignIn _googleSignOut = GoogleSignIn();

     Future<void> signOut() async {
    try {
      // Sign out from Google Sign-In
      if (await _googleSignOut.isSignedIn()) {
        await _googleSignOut.signOut();
        print("Google account signed out.");
      }

      // Sign out from Firebase
      await _auth.signOut();
      print("Firebase user signed out.");
    } catch (e) {
      print("Error signing out: $e");
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(), body: Center(child: ElevatedButton(onPressed: (){
      signOut();
        Navigator.push(context, MaterialPageRoute(builder: (context) {
                          return Loginform();
                         }));

    }, child: Text('Sign Out')),),);
  }
}